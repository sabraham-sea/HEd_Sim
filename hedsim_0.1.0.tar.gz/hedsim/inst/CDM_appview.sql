SELECT
   1 from
FROM higher_education_cdm.outcometrackeddetails
